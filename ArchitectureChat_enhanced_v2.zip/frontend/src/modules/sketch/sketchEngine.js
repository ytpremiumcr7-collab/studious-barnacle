
export function generateFacadePaths(params) {
  const { floors } = params;
  const paths = [
    "M100 500 L700 500",
    "M150 500 L150 300 L650 300 L650 500"
  ];
  if (floors === 2) {
    paths.push("M150 300 L150 150 L650 150 L650 300");
  }
  return paths;
}
