
export const residentialRules = {
  recamara: { minArea: 9, minWidth: 2.7 },
  baño: { minArea: 3, minWidth: 1.2 },
  sala: { minArea: 12 }
};
