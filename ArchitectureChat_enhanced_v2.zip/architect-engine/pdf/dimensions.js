
export function getDimensions(layout){
  return layout.map(r=>({
    name: r.tipo,
    width: r.width,
    height: r.height
  }));
}
