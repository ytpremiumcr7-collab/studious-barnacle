
export function calculateAreas(layout){
  let total = 0;
  const list = layout.map(r=>{
    const a = r.width * r.height;
    total += a;
    return { name:r.tipo, area:a };
  });
  return { list, total };
}
