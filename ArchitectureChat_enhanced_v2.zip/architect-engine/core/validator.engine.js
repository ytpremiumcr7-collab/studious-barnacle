
export function validateLayout(layout, ruleset) {
  const errors = [];
  layout.forEach(room => {
    const rule = ruleset[room.tipo];
    if (!rule) return;

    if (rule.minArea && room.area < rule.minArea) {
      errors.push({ type: "area", room, required: rule.minArea });
    }
    if (rule.minWidth && room.width < rule.minWidth) {
      errors.push({ type: "width", room, required: rule.minWidth });
    }
  });
  return errors;
}
