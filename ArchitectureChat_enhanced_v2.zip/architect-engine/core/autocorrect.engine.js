
export function autoCorrect(layout, errors) {
  return layout.map(room => {
    const errs = errors.filter(e => e.room === room);
    errs.forEach(e => {
      if (e.type === "area") {
        const f = e.required / room.area;
        room.width *= Math.sqrt(f);
        room.height *= Math.sqrt(f);
        room.area = room.width * room.height;
      }
      if (e.type === "width") {
        room.width = e.required;
        room.area = room.width * room.height;
      }
    });
    return room;
  });
}
