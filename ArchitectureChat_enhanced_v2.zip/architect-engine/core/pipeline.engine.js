
import { validateLayout } from "./validator.engine.js";
import { autoCorrect } from "./autocorrect.engine.js";

export function processLayout(layout, rules) {
  let errors, i=0;
  do {
    errors = validateLayout(layout, rules);
    if(errors.length) layout = autoCorrect(layout, errors);
    i++;
  } while(errors.length && i<5);

  return { layout, errors, iterations:i };
}
