// ============================================================
// ARCHMOTOR SERVICE WORKER
// Soporte offline para PWA
// ============================================================

const CACHE_NAME = 'archmotor-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
];

// Instalar - cachear assets estaticos
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(STATIC_ASSETS);
    }).then(() => {
      self.skipWaiting();
    })
  );
});

// Activar - limpiar caches antiguos
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    }).then(() => {
      self.clients.claim();
    })
  );
});

// Fetch - estrategia stale-while-revalidate
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Solo manejar GET requests
  if (request.method !== 'GET') return;

  // Estrategia: Network first, fallback a cache
  event.respondWith(
    fetch(request)
      .then((networkResponse) => {
        // Cachear la respuesta nueva
        if (networkResponse.ok) {
          const clone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, clone);
          });
        }
        return networkResponse;
      })
      .catch(() => {
        // Fallback a cache si falla la red
        return caches.match(request).then((cachedResponse) => {
          if (cachedResponse) {
            return cachedResponse;
          }
          // Si no esta en cache y es una navegacion, mostrar offline
          if (request.mode === 'navigate') {
            return caches.match('/');
          }
          return new Response('Sin conexion', { status: 503 });
        });
      })
  );
});
